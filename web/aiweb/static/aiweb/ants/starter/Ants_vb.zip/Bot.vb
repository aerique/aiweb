Public Interface Bot
    Sub DoSetup(ByVal a As Ants)
    Sub DoTurn(ByVal a As Ants)
    Sub DoEnd(ByVal a As Ants)
End Interface

