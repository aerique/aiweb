# Pascal Starter Package for Ant Wars

Tested with FreePascal 2.4.0 64-bit on Linux.
