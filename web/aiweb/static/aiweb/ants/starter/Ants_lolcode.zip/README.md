See http://icanhaslolcode.org/ for installation instructions.
