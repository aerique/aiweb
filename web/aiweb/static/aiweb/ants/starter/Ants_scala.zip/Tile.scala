case class Tile(column: Int, row: Int)
