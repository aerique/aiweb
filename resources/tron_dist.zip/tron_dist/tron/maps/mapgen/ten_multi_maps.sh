for f in tron_multi_0{0..9}.map
do
   ./symmetric_mapgen.py > "$f"
done
