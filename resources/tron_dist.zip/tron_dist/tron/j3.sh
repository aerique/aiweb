#!/bin/sh

./playgame.py --verbose --fill --log_input --log_output --log_error \
--log_dir game_logs --turns 1000 --turntime 300 \
--map_file maps/multi/hand/tron_03_00.map \
/home/smiley/ast/source/ocaml_tron_ocmc/MyBot.native
#/home/smiley/ast/source/tron_uct/MyBot.native
