#!/bin/sh

./playgame.py --verbose --fill --log_input --log_output --log_error \
--log_dir game_logs --turns 1000 --turntime 1000 \
--map_file maps/single/tron_01.map \
/home/smiley/ast/source/ocaml_tron_starter/MyBot.native \
#/home/smiley/ast/source/tron_uct/MyBot.native
