BROWSER=chromium python2 playgame.py -v -l game_logs -I -O -E -S --turns 300 --map_file maps/test/war_p02_01.map \
"/home/smiley/ast/source/smiley-aichallenge/aichallenge/wargame/dist/starter_bots/ocaml/MyBot.native" \
"/home/smiley/ast/source/smiley-aichallenge/aichallenge/wargame/dist/starter_bots/ocaml/MyBot.native" \
