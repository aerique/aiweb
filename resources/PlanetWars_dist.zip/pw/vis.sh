BROWSER=chromium python visualizer/visualize_locally.py < game_logs/0.replay
