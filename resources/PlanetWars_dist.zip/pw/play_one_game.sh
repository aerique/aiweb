#!/bin/sh

./playgame.py --verbose --fill --log_input --log_output --log_error \
--log_dir game_logs  --log_stderr --turns 200 --turntime 1000 \
--map_file maps/pw_115.map \
"python2 dist/starter_bots/python/MyBot.py" \
"python2 dist/starter_bots/python/MyBot.py"

#--map_file maps/tron_00.map \

